/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete2;

/**
 *
 * @author reroes
 */
public class Clase2 {

    public static void main(String[] args) {
        /**
         *
         */
        int valor1 = 2;
        double valor2 = 10.2;

        // int valor3 = valor1 / valor2;
        double valor3 = valor1 / valor2;
        System.out.printf("Valor resultante: %.2f\n", valor3);
    }
}
